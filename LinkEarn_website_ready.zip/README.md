# LinkEarn

A starter link-shortener website with:
- Short-link creation
- Redirect/countdown page
- Click counter
- Simple ad-placement placeholders
- Basic stats API

## Run locally

Install Node.js, then:

```bash
npm install
npm start
```

Open:
http://localhost:3000

## Important before publishing

1. Add a real admin login/authentication.
2. Use a proper database for production.
3. Add HTTPS.
4. Apply to an advertising/affiliate network that accepts your site.
5. Replace the `ADVERTISEMENT` placeholders only with code supplied by the approved network.
6. Never ask or force visitors to click ads. Do not use fake clicks, bots, auto-clicks, or misleading buttons.
7. Add Privacy Policy, Terms, and Contact pages before monetization.

## Stats

For a generated code, open:

`/api/links/CODE`

The response includes the destination and click count.

## Hosting

This project can be deployed to a Node.js-compatible host. Set the start command to:

`npm start`
