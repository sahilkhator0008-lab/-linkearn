const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function loadData() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return { links: {} };
  }
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function validUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === "https:" || u.protocol === "http:";
  } catch {
    return false;
  }
}

app.post("/api/links", (req, res) => {
  const { url } = req.body || {};
  if (!validUrl(url)) {
    return res.status(400).json({ error: "Please enter a valid http/https URL." });
  }

  const data = loadData();
  let code = crypto.randomBytes(4).toString("base64url");
  while (data.links[code]) code = crypto.randomBytes(4).toString("base64url");

  data.links[code] = {
    url,
    createdAt: new Date().toISOString(),
    clicks: 0
  };
  saveData(data);

  res.json({
    code,
    shortUrl: `${req.protocol}://${req.get("host")}/go/${code}`
  });
});

app.get("/api/links/:code", (req, res) => {
  const data = loadData();
  const item = data.links[req.params.code];
  if (!item) return res.status(404).json({ error: "Link not found." });

  res.json({
    code: req.params.code,
    destination: item.url,
    clicks: item.clicks,
    createdAt: item.createdAt
  });
});

app.get("/go/:code", (req, res) => {
  const data = loadData();
  const item = data.links[req.params.code];

  if (!item) return res.status(404).send("Link not found.");

  item.clicks += 1;
  saveData(data);

  res.sendFile(path.join(__dirname, "public", "redirect.html"));
});

app.get("/api/redirect/:code", (req, res) => {
  const data = loadData();
  const item = data.links[req.params.code];
  if (!item) return res.status(404).json({ error: "Link not found." });
  res.json({ destination: item.url });
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"));
});

app.listen(PORT, () => {
  console.log(`LinkEarn running on port ${PORT}`);
});